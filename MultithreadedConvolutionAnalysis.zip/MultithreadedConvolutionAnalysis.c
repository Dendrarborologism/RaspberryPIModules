#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/timerfd.h>
#include <inttypes.h>
#include <time.h>
#include <semaphore.h>
#include <errno.h>
#define ANALYSIS //macro to make sampling runtime data from the program easier. Comment out to see the results of each convolution 
//Declare structure to hold the convolution info (Like number of rows/cols)
typedef struct _ConvInfo
{
    int rows; //rows of the matrix 
    int cols; //cols of the matrix 
    int filter_rows; //rows of the filter
    int filter_cols; //cols of the filter
    int **matrix; //the matrix to convolve
    int **filter_vector; //the filter by which to convolve the matrix 
    int row_to_convolve; //the row to convolve for thread-by-row
    int col_to_convolve; //the column to convolve for thread-by-element
} ConvInfo; 
//helper function declarations 
void print_matrix(int **arr, int numRows, int numCols); 
int **init_matrix(int rows, int cols); //initializes a 2d matrix given the row and column count
void free_matrix(int **matrix, int rows); //frees a 2d matrix given the row count 
void clear_matrix(int **matrix, int rows, int cols); //set all cells to zero
void free_ConvInfo(ConvInfo *info); //frees a ConvInfo *
void print_row(int **matrix, int row, int cols); //prints the row of a matrix 
 
//Declare Variables to store the given matrix and final results
int **convolved_matrix;  
int conv_count1 = 0; 
int conv_count2 = 0;
int conv_count3 = 0;
// 1. Single thread to evaluate the convolution 
void *ConvolutionPerMatrix(void *info)
{
//get the Convolution info
    int rows = ((ConvInfo *)info)->rows; 
    int cols = ((ConvInfo *)info)->cols; 
    int **matrix = ((ConvInfo *)info)->matrix; 
    int **filter_vector = ((ConvInfo *)info)->filter_vector;    
// Loop through the matrix based on the info
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            //if at the beginning, just ignore the first element of the filter vector
            if (j == 0)
            {
                convolved_matrix[i][0] = (filter_vector[0][1] * matrix[i][0]) + 
                                         (filter_vector[0][2] * matrix[i][1]);
                conv_count1++; 
                continue; 
            }
            //if at the end, just ignore the last element of the filter vector 
            if (j == cols-1)
            {
                convolved_matrix[i][cols-1] = (filter_vector[0][0] * matrix[i]
[cols-2]) + 
                                              (filter_vector[0][1] * matrix[i]
[cols-1]);
                conv_count1++; 
                continue; 
            }
            //if not at either end of the current matrix row, then multiply each filter vector 
            //element with its corresponding matrix element 
            convolved_matrix[i][j] = (filter_vector[0][0]*matrix[i][j-1]) + 
                                     (filter_vector[0][1]*matrix[i][j]) + 
                                     (filter_vector[0][2]*matrix[i][j+1]); 
            conv_count1++;
        }
    }
pthread_exit(NULL); 
    //return NULL; 
}
// 2. Thread function to process one row of the given matrix
void *ConvolveOneRow(void *info)
{
    //get the Convolution info 
    int cols = ((ConvInfo *)info)->cols; 
    int **matrix = ((ConvInfo *)info)->matrix; 
    int **filter_vector = ((ConvInfo *)info)->filter_vector; 
    int row = ((ConvInfo *)info)->row_to_convolve; 
    for (int j = 0; j < cols; j++)
    {
        //if at the beginning, just ignore the first element of the filter vector
        if (j == 0)
        {
            convolved_matrix[row][0] = (filter_vector[0][1] * matrix[row][0]) + 
                                       (filter_vector[0][2] * matrix[row][1]);
            conv_count2++;
            continue; 
        }
        //if at the end, just ignore the last element of the filter vector 
        if (j == cols-1)
        {
            convolved_matrix[row][cols-1] = (filter_vector[0][0] * matrix[row]
[cols-2]) + 
                                                  (filter_vector[0][1] * 
matrix[row][cols-1]);
            conv_count2++;
            continue; 
        }
        //if not at either end of the current matrix row, then multiply each filter vector 
        //element with its corresponding matrix element 
        convolved_matrix[row][j] = (filter_vector[0][0]*matrix[row][j-1]) + 
                                   (filter_vector[0][1]*matrix[row][j]) + 
                                   (filter_vector[0][2]*matrix[row][j+1]); 
        conv_count2++;
    }
    //print_row(convolved_matrix, row, cols);  
    pthread_exit(NULL);
    //return NULL; 
}
// 3. Thread to process each element of the matrix.
void *ConvolveEachCell(void *info)
{
    //get the Convolution info 
    int cols = ((ConvInfo *)info)->cols; 
    int **matrix = ((ConvInfo *)info)->matrix; 
    int **filter_vector = ((ConvInfo *)info)->filter_vector; 
    int row = ((ConvInfo *)info)->row_to_convolve; 
    int col = ((ConvInfo *)info)->col_to_convolve;
    
    
    //logic for the first element of the rows
    if (0 == col) 
    {
        convolved_matrix[row][col] = (filter_vector[0][1]*matrix[row][col]) +
                                     (filter_vector[0][2]*matrix[row][col+1]);
    }
    else 
    {
        //logic for the last element of the rows
        if (cols-1 == col)
        {
            convolved_matrix[row][col] = (filter_vector[0][0]*matrix[row][col-1]) +
                                         (filter_vector[0][1]*matrix[row][col]);
        }
        //logic for every other element of the matrix
        else
        {
            convolved_matrix[row][col] = (filter_vector[0][0]*matrix[row][col-1]) +
                                         (filter_vector[0][1]*matrix[row][col]) + 
                                         (filter_vector[0][2]*matrix[row][col+1]); 
        }
    }
    conv_count3++; 
    pthread_exit(NULL);
}
// Main function
int main(int argc, char *argv[]) {
    
    // Define variables
    ConvInfo info; 
    int **matrix;
// Step-1
    // ======
    // Read the file and load the data matrix and filter vector information
    FILE *fp = fopen(argv[1], "r"); 
    if (!fp)
    {
        fprintf(stderr, "Couldn't open file\n");
        return 1; 
    }
    // into a 2D and 1D array respectively.
// Scan in matrix size using fscanf
    if (2 != fscanf(fp, "%d %d", &(info.rows), &(info.cols)))
    {
        fprintf(stderr, "Couldn't read in matrix size\n"); 
        return 1; 
    }
    //initialize the original matrix
    matrix = init_matrix(info.rows, info.cols); 
    for (int i = 0; i < info.rows; i++)
    {      
        if (10 != fscanf(fp, "%d %d %d %d %d %d %d %d %d %d", 
                                &matrix[i][0],
                                &matrix[i][1],
                                &matrix[i][2],
                                &matrix[i][3],
                                &matrix[i][4],
                                &matrix[i][5],
                                &matrix[i][6],
                                &matrix[i][7],
                                &matrix[i][8],
                                &matrix[i][9]))
        {
            fprintf(stderr, "Error reading matrix data\n"); 
            return 1; 
        } 
    }
    convolved_matrix = init_matrix(info.rows, info.cols); //initialize the convolved matrix
    info.matrix = matrix;  
    // Print the original matrix
#ifndef ANALYSIS
    printf("Original matrix: \n"); 
    print_matrix(info.matrix, info.rows, info.cols); 
#endif
    // Scan in filter size
    if (2 != fscanf(fp, "%d %d", &(info.filter_rows), &(info.filter_cols)))
    {
        fprintf(stderr, "Couldn't read in filter size\n"); 
        return 1; 
    }
    //initialize the filter matrix
    int **filter_vector = init_matrix(info.filter_rows, info.filter_cols); 
    if (3 != fscanf(fp, "%d %d %d", &filter_vector[0][0], &filter_vector[0][1], 
&filter_vector[0][2]))
    {
        fprintf(stderr, "Error reading in filter data\n"); 
    }
    fclose(fp); //close the file
    info.filter_vector = filter_vector;
    // Print the filter matrix
#ifndef ANALYSIS
    printf("Filter: \n"); 
    print_matrix(info.filter_vector, info.filter_rows, info.filter_cols); 
#endif
   
// Step-2
    // ======
    // Convolve using a single thread.
    struct timeval start1, end1, start2, end2, start3, end3; 
    gettimeofday(&start1, NULL);
    pthread_t thread_id; 
    if (pthread_create(&thread_id, NULL, ConvolutionPerMatrix, &info))
    {
        fprintf(stderr, "Couldn't create single thread\n");
        return 1; 
    } 
    if (pthread_join(thread_id, NULL))
    {
        fprintf(stderr, "Couldn't join single thread\n");
        return 1; 
    }
    gettimeofday(&end1, NULL);
    double elapsed1 = (end1.tv_sec - start1.tv_sec)
                    +(end1.tv_usec - start1.tv_usec) / 1000000.0;
#ifndef ANALYSIS
    printf("Convolved matrix: \n"); 
    print_matrix(convolved_matrix, info.rows, info.cols); 
#endif
    clear_matrix(convolved_matrix, info.rows, info.cols); //reset the convolution matrix
    printf("Convolution count 1: %d\nTime for single thread: %lf\n", conv_count1, 
elapsed1); 
    //printf("Convolved matrix after clear: \n");
    //print_matrix(convolved_matrix, info.rows, info.cols); 
// Print out search count with 1 thread and the time it took
// Step-3
    // ======
    // Convolution using 1 thread per row
    printf("\n\n**Case-2: Convolution using single thread per row**\n");
#define NUM_ROWS info.rows
#define NUM_COLS info.cols
#define NUM_CELLS NUM_ROWS * NUM_COLS 
    gettimeofday(&start2, NULL);
    pthread_t row_threads[NUM_ROWS]; 
    ConvInfo info_rows[NUM_ROWS]; 
    //initializes an array of ten ConvInfo structs to be used in the threads 
    for (int i = 0; i < NUM_ROWS; i++)
    {
        memcpy(&info_rows[i], &info, sizeof(ConvInfo)); 
        info_rows[i].row_to_convolve = i; 
        //printf("Before thread %d created\n", j);
        //creates a thread for each row 
        if(pthread_create(&row_threads[i], NULL, ConvolveOneRow, &info_rows[i]))
        {
            fprintf(stderr, "Couldn't create row thread\n");
            return 1; 
        }  
        //printf("After thread %d created\n", j);
    }
    //wait for all the threads to finish 
    for (int k = 0; k < NUM_ROWS; k++)
    {
        if (pthread_join(row_threads[k], NULL))
        {
            fprintf(stderr, "Couldn't join row thread\n"); 
            return 1;
        }
    }
    gettimeofday(&end2, NULL);
    double elapsed2 = (end2.tv_sec - start2.tv_sec)
                    +(end2.tv_usec - start2.tv_usec) / 1000000.0;
    printf("Convolution count 2: %d\nTime for threads by row: %lf\n", conv_count2, 
elapsed2);
#ifndef ANALYSIS
    printf("Convolved matrix: \n"); 
    print_matrix(convolved_matrix, info.rows, info.cols);
#endif
    clear_matrix(convolved_matrix, info.rows, info.cols); //reset the convolution matrix
    // Step-4
    // ======
    // Convolution with 1 thread per element
    printf("\n\n**Case 3: Convolution with 1 thread per element\n");
    gettimeofday(&start3, NULL);
    pthread_t cell_threads[NUM_ROWS][NUM_COLS]; //matrix of thread ids  
    ConvInfo info_cells[NUM_ROWS][NUM_COLS]; //matrix of ConvInfo structs with the same size as the matrix 
    for (int i = 0; i < NUM_ROWS; i++)
    {
        for (int j = 0; j < NUM_COLS; j++)
        {
            //initialize the index info for each element in the matrix to be used in the thread associated with
            //that 
            //printf("Breakpoint one\n"); 
            memcpy(&info_cells[i][j], &info, sizeof(ConvInfo)); 
            info_cells[i][j].row_to_convolve = i; 
            info_cells[i][j].col_to_convolve = j; 
            //printf("Before thread %d, %d created\n", i, j);
            //create the threads
            if(pthread_create(&cell_threads[i][j], NULL, ConvolveEachCell, 
&info_cells[i][j]))
            {
                fprintf(stderr, "Couldn't create cell thread\n");
                return 1; 
            } 
            //printf("After thread %d, %d created\n", i, j);
        }
    }
    
    //waits for all threads to finish executing 
    for (int i = 0; i < NUM_ROWS; i++)
    {
        for(int j = 0; j < NUM_COLS; j++)
        {
            if (pthread_join(cell_threads[i][j], NULL))
            {
                fprintf(stderr, "Couldn't join cell thread\n"); 
                return 1;
            }
        }
    }
    gettimeofday(&end3, NULL);
    double elapsed3 = (end3.tv_sec - start3.tv_sec)
                    +(end3.tv_usec - start3.tv_usec) / 1000000.0;
    printf("Convolution count 3: %d\nTime for threads by element: %lf\n", 
conv_count3, elapsed3);
#ifndef ANALYSIS
    printf("Convolved matrix: \n"); 
    print_matrix(convolved_matrix, info.rows, info.cols);
#endif
    //free all of the remaining memory
    free_matrix(info.matrix, info.rows); 
    free_matrix(info.filter_vector, info.filter_rows);
    free_matrix(convolved_matrix, info.rows);
    return 0;
}
// Helper Functions
// ================
//Function to print out the result matrix
void print_matrix(int **arr, int numRows, int numCols){
    printf("\n");
    for(int i = 0; i < numRows; i++){
        for(int j = 0; j < numCols; j++){
            printf("%3d ",arr[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
//initializes a matrix with `rows` rows and `cols` cols 
int **init_matrix(int rows, int cols)
{
    int **matrix = (int **)malloc(rows*sizeof(int *)); 
    if (!matrix)
    {
        return NULL; 
    }
    for (int i = 0; i < rows; i++)
    {
        matrix[i] = malloc(cols*sizeof(int)); 
        if (!(matrix[i]))
        {
            return NULL; 
        }
    }
    return matrix; 
}
//frees up a matrix 
void free_matrix(int **matrix, int rows)
{
    for (int i = 0; i < rows; i++)
    {
        free(matrix[i]); 
    }
    free(matrix); 
}
//sets every element of a matrix to 0 
void clear_matrix(int **matrix, int rows, int cols)
{
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            matrix[i][j] = 0; 
        }
    }
}
//frees a ConvInfo * 
void free_ConvInfo(ConvInfo *info)
{
    free(info->matrix); 
    free(info->filter_vector); 
    free(info); 
}
//prints a single row of a matrix 
void print_row(int **matrix, int row, int cols)
{
    for (int i = 0; i < cols; i++)
    {
        printf("%d ", matrix[row][i]);
    }
}