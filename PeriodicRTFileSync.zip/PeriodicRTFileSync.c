#include <fcntl.h>
#include <getopt.h>
#include <linux/types.h>
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include<sys/time.h> 
#define MY_PRIORITY (49)  // kernel is priority 50
#define PERIOD 600000
void print_results();
void print_buffer(char buffer[][256], size_t rows); 
//Define global variables
char fullString[20][256];
typedef struct _Buffers {
    char sBuffer1[10][256];        
    char sBuffer2[10][256];
}Buffers;
// Timer Functions
// ===============
// Timer related structures and functions:
typedef struct __period_info {
    struct timespec next_period;        // sec, nano-sec
    long period_ns;
} period_info;
// Thread related Real-time functions
// ========================
static void periodic_task_init(period_info *pinfo, long period);
static void increment_period(period_info *pinfo);
static void wait_rest_of_period(period_info *pinfo);
// Thread-1 to read from "first.txt"
//type(ptr) == Buffers *
void *getFirstThd(void *ptr)
{
    char buffer[10][256] = {0};  
    //memcpy(buffer, ((Buffers *)ptr)->sBuffer1, sizeof(buffer)); 
    // Declare it as a real time task and pass the necessary params to the scheduler 
    struct sched_param param;
    param.sched_priority = MY_PRIORITY;
    if (sched_setscheduler(0, SCHED_FIFO, &param) == -1) {
        printf("Run the program as a sudo user\n");
        perror("sched_setscheduler failed, thread 1");
        exit(20);
    }
    
    //Open File 
    FILE *fp = fopen("first.txt", "r"); 
    //Check to make sure file opened correctly
    if (NULL == fp)
    {
        fprintf(stderr, "Couldn't open first.txt\n");
        pthread_exit(0);  
    }
    period_info pinfo; 
    long period = PERIOD; //quarter of a second wait to be safe 
    char *line = NULL; 
    size_t len = 0; 
    size_t idx = 0; 
    // Initialize the periodic Task and read line at a time from "First.txt"
    periodic_task_init(&pinfo, period); 
    while (-1 != getline(&line, &len, fp))
    {
        //Read a line then wait_rest_of_period
        //copy in the read line 
        strncpy(buffer[idx], line, sizeof(buffer[idx]) - 1);
        //make sure to null terminate  
        buffer[idx][sizeof(buffer[idx]) - 1] = '\0'; 
        //print_buffer(buffer, idx+1);
        //printf("Thread 1 has run %lu times\n", idx+1);
        //memcpy(((Buffers *)ptr)->sBuffer1, buffer[idx], sizeof(buffer[idx]));
        idx++; 
        wait_rest_of_period(&pinfo); 
    }
    fclose(fp); 
    free(line); 
    //pass the read line back to the the param by reference 
    memcpy(((Buffers *)ptr)->sBuffer1, buffer, idx * sizeof(buffer[0]));
    //Exit pthread
    pthread_exit(0); 
}
// Thread-2 to read from "second.txt"
//type(ptr) == Buffers *
void *getSecThd(void *ptr)
{
    char buffer[10][256] = {0};  
    //memcpy(buffer, ((Buffers *)ptr)->sBuffer2, sizeof(buffer)); 
    //Declare it as a real time task and pass the necessary params to the scheduler 
    struct sched_param param;
    param.sched_priority = MY_PRIORITY;
    if (sched_setscheduler(0, SCHED_FIFO, &param) == -1) {
        printf("Run the program as a sudo user\n");
        perror("sched_setscheduler failed, thread 2");
        exit(20);
    }
    
    //Open File 
    FILE *fp = fopen("second.txt", "r"); 
    //Check to make sure file opened correctly
    if (NULL == fp)
    {
        fprintf(stderr, "Couldn't open second.txt\n"); 
        pthread_exit(0); 
    }
            
    period_info pinfo; 
    long period = PERIOD; //quarter of a second wait to be safe 
    char *line = NULL; 
    size_t len = 0; 
    size_t idx = 0; 
    //Initialize the periodic Task and read line at a time from "second.txt"
    periodic_task_init(&pinfo, period); 
    //Read a line then wait_rest_of_period
    while (-1 != getline(&line, &len, fp))
    {
        //printf("Thread 2 has run %lu times\n", idx+1);
        //copy in the read line 
        strncpy(buffer[idx], line, sizeof(buffer[idx]) - 1);
        //make sure to null terminate  
        buffer[idx][sizeof(buffer[idx]) - 1] = '\0'; 
        //memcpy(((Buffers *)ptr)->sBuffer2, buffer[idx], sizeof(buffer[idx]));
        //printf("%s", buffer[idx]); 
        //print_buffer(buffer, idx+1);
        //printf("Thread 2 has run %lu times\n", idx+1);
        idx++; 
        if (idx >= 10)
        {
            break; 
        }
        wait_rest_of_period(&pinfo); 
    }
    fclose(fp); 
    free(line); 
    //pass the read line back to the the param by reference 
    //copies in only the actual read lines via idx
    memcpy(((Buffers *)ptr)->sBuffer2, buffer, idx * sizeof(buffer[0]));
    //Exit pthread
    pthread_exit(0); 
}
// Thread-3 to copy the results into final buffer.
void *getThirdThd(void *ptr)
{
    //Declare it as a real time task and pass the necessary params to the scheduler 
    struct sched_param param;
    param.sched_priority = MY_PRIORITY;
    if (sched_setscheduler(0, SCHED_FIFO, &param) == -1) {
        printf("Run the program as a sudo user\n");
        perror("sched_setscheduler failed, thread 2");
        exit(20);
    }
    long period = PERIOD; 
    period_info pinfo; 
    periodic_task_init(&pinfo, period);
//#define DEBUG
    //write to the shared buffer fullString two lines at a time 
    for (int i = 0, buff1 = 0, buff2 = 0; i < 19; i+=2)
    { 
        //give the other two threads time (5ms) to write to their respective buffers 
        usleep(5000);
        //copy the first buffer's line into the shared buffer fullString
        memcpy(fullString[i], ((Buffers *)ptr)->sBuffer1[buff1], 
        sizeof(fullString[i]));
#ifdef DEBUG
            printf("%s", fullString[i]); 
#endif 
        buff1++; 
        //copy the second buffer's line into the shared buffer fullString
        memcpy(fullString[i+1], ((Buffers *)ptr)->sBuffer2[buff2], 
        sizeof(fullString[i]));
#ifdef DEBUG
        printf("%s", fullString[i+1]); 
#endif 
        buff2++; 
        wait_rest_of_period(&pinfo); 
    }
    pthread_exit(0); 
}
int main(void) 
{
    //Declare variables
    pthread_t thrd1, thrd2, thrd3;
    struct timeval start, end; 
    size_t rows = 10; 
    Buffers myBuffers;
    memset(&myBuffers, 0, sizeof(Buffers)); 
    // Create 3 different threads. First 2 threads will read from two
    // separate files and the 3rd will merge the two sets of information into
    // one.
#define THREAD1
#define THREAD2
    gettimeofday(&start, NULL); 
#ifdef THREAD1
    if (pthread_create(&thrd1, NULL, getFirstThd, (void *)&myBuffers))
    {
    fprintf(stderr, "Couldn't create thread 1\n"); 
    return 1; 
    }
#endif
#ifdef THREAD2
    if(pthread_create(&thrd2, NULL, getSecThd, (void *)&myBuffers))
    {
    fprintf(stderr, "Couldn't create thread 2\n"); 
    return 1;
    }
#endif
    if (pthread_create(&thrd3, NULL, getThirdThd, (void *)&myBuffers))
    {
    fprintf(stderr, "Couldn't create thread 3\n"); 
    return 1;
    }
#ifdef THREAD1
    if(pthread_join(thrd1, NULL))
    {
    fprintf(stderr, "Couldn't join thread 1\n"); 
    return 1;
    } 
#endif
#ifdef THREAD2
    if (pthread_join(thrd2, NULL))
    {
    fprintf(stderr, "Couldn't create thread 2\n"); 
    return 1;
    }
#endif
    if(pthread_join(thrd3, NULL))
    {
    fprintf(stderr, "Couldn't join thread 3\n"); 
    return 1;
    }
#ifdef THREAD1
    //print_buffer(myBuffers.sBuffer1, rows);
#endif
#ifdef THREAD2
    //print_buffer(myBuffers.sBuffer2, rows);
#endif
    gettimeofday(&end, NULL); 
    double elapsed = (end.tv_sec - start.tv_sec)
                        +(end.tv_usec - start.tv_usec) / 1000000.0;
    printf("\nTotal time to compute: %lf seconds\nPeriod: %d microseconds\n\
    nResult: \n\n", elapsed, PERIOD);
    print_buffer(fullString, rows*2); 
}
// Helper Functions
// ================
// Function to print out results
void print_results()
{
    //Print out full string
    for (int i = 0; i < 20; i++)
    {
        for (int j = 0; j < 256; j++)
        {
            printf("%c", fullString[i][j]); 
        }
        printf("\n"); 
    }
}
//detemines the starting time of the thread
static void periodic_task_init(period_info *pinfo, long period)
{
    pinfo->period_ns = period; 
    //get the current time of the unaltered clock 
    clock_gettime(CLOCK_MONOTONIC, &(pinfo->next_period));
}
//determines the ending time of the thread based on the initialized time
static void increment_period(period_info *pinfo)
{
    //specify when the next cycle will happen by incrementing by the period 
    pinfo->next_period.tv_nsec += pinfo->period_ns;
    //because timespec is a two-part struct but we're only incrementing the small(nanosecond)
    //part of it, occasionally we will run into an overflow, so the next loop updates the
    //whole-seconds part of the struct (timespec.tv_sec) 
    while (pinfo->next_period.tv_nsec >= 1000000000) 
    {
        /* timespec nsec overflow */
        pinfo->next_period.tv_sec++;
        //sets the nanosecond portion to the remainder (the amount by which next_period.tv_nsec overflows)
        pinfo->next_period.tv_nsec = pinfo->next_period.tv_nsec - 1000000000;
    }
}
//a function to sleep for the remaining time of the period after finishing the task
static void wait_rest_of_period(period_info *pinfo)
{
    //get the start time for the next cycle 
    increment_period(pinfo);
    //wait for the time in the next_period timespec struct to happen
    //uses absolute time of the clock to wait until that point 
    int ret = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &pinfo->next_period, NULL);
    if (EINTR == ret) 
    {
        fprintf(stderr, "Sleep interrupted by a signal\n");
    }
    else if (0 != ret)
    {
        fprintf(stderr, "clock_nanosleep error");
    }
}
void print_buffer(char buffer[][256], size_t rows)
{
    for (size_t i = 0; i < rows; i++)
    {
        if(buffer[i][0] != '\0')
        {
            printf("%s", buffer[i]); 
        }
    }
}